from django.db import models
from main.models import Book

# Create your models here.
