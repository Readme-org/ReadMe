from django.apps import AppConfig


class WishlistbookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wishlistBook'
